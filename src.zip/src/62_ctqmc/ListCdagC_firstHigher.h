  INTEGER                      :: old_tail
  INTEGER                      :: L_tail
  INTEGER                      :: begin
  INTEGER                      :: firstHigher
