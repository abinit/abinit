  INTEGER                                 :: index
  INTEGER                                 :: activeF
  DOUBLE PRECISION                        :: ratioh
  DOUBLE PRECISION                        :: fsign
  DOUBLE PRECISION                        :: t_val
  DOUBLE PRECISION                        :: hybrid

  activeF = this%activeFlavor
