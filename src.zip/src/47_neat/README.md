# What is this

Neat is the NEw Abinit Testing tool. In this folder are tools for use in Fortran to produce
structured data output. These data are to be used by the python side of the project in
smart testing.
